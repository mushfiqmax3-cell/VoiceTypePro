package com.example

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class TranscriptionRecord(
    val id: Long,
    val text: String,
    val timestamp: Long,
    val modelUsed: String
)

/**
 * Manages secure storage for the Gemini API key via EncryptedSharedPreferences,
 * model configuration, last floating bubble position, and the last 20 transcriptions.
 */
object Prefs {
    private const val ENCRYPTED_PREFS_NAME = "voicetype_secure_prefs"
    private const val STANDARD_PREFS_NAME = "voicetype_standard_prefs"

    private const val KEY_API_KEY = "gemini_api_key"
    private const val KEY_SEEDED_INITIAL = "seeded_initial_key"
    private const val KEY_MODEL_NAME = "gemini_model_name"
    private const val KEY_BUBBLE_X = "bubble_pos_x"
    private const val KEY_BUBBLE_Y = "bubble_pos_y"
    private const val KEY_HISTORY_JSON = "transcription_history_json"

    const val DEFAULT_MODEL_NAME = "gemini-3.5-transcribe"
    const val FALLBACK_MODEL_NAME = "gemini-2.5-flash"
    private const val MAX_HISTORY_ITEMS = 20

    private val _historyFlow = MutableStateFlow<List<TranscriptionRecord>>(emptyList())
    val historyFlow: StateFlow<List<TranscriptionRecord>> = _historyFlow.asStateFlow()

    private fun getSecurePrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                ENCRYPTED_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback to standard private preferences only if keystore fails in test environments
            context.applicationContext.getSharedPreferences(ENCRYPTED_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    private fun getStandardPrefs(context: Context): SharedPreferences {
        return context.applicationContext.getSharedPreferences(STANDARD_PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun init(context: Context) {
        val securePrefs = getSecurePrefs(context)
        val alreadySeeded = securePrefs.getBoolean(KEY_SEEDED_INITIAL, false)
        if (!alreadySeeded) {
            val buildConfigKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (_: Exception) {
                ""
            }
            if (buildConfigKey.isNotBlank() &&
                buildConfigKey != "MY_GEMINI_API_KEY" &&
                buildConfigKey != "null"
            ) {
                securePrefs.edit()
                    .putString(KEY_API_KEY, buildConfigKey.trim())
                    .putBoolean(KEY_SEEDED_INITIAL, true)
                    .apply()
            } else {
                securePrefs.edit()
                    .putBoolean(KEY_SEEDED_INITIAL, true)
                    .apply()
            }
        }
        _historyFlow.value = loadHistory(context)
    }

    fun getApiKey(context: Context): String {
        val stored = getSecurePrefs(context).getString(KEY_API_KEY, "")?.trim().orEmpty()
        if (stored.isNotEmpty()) return stored

        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
        return if (buildConfigKey.isNotBlank() &&
            buildConfigKey != "MY_GEMINI_API_KEY" &&
            buildConfigKey != "null"
        ) {
            buildConfigKey.trim()
        } else {
            ""
        }
    }

    fun saveApiKey(context: Context, apiKey: String) {
        getSecurePrefs(context).edit()
            .putString(KEY_API_KEY, apiKey.trim())
            .putBoolean(KEY_SEEDED_INITIAL, true)
            .apply()
    }

    fun getModelName(context: Context): String {
        val stored = getStandardPrefs(context).getString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME)?.trim()
        return if (stored.isNullOrEmpty()) DEFAULT_MODEL_NAME else stored
    }

    fun saveModelName(context: Context, modelName: String) {
        val clean = modelName.trim().ifEmpty { DEFAULT_MODEL_NAME }
        getStandardPrefs(context).edit().putString(KEY_MODEL_NAME, clean).apply()
    }

    fun saveBubblePosition(context: Context, x: Int, y: Int) {
        getStandardPrefs(context).edit()
            .putInt(KEY_BUBBLE_X, x)
            .putInt(KEY_BUBBLE_Y, y)
            .apply()
    }

    fun getBubblePosition(context: Context, defaultX: Int = 0, defaultY: Int = 260): Pair<Int, Int> {
        val prefs = getStandardPrefs(context)
        val x = prefs.getInt(KEY_BUBBLE_X, defaultX)
        val y = prefs.getInt(KEY_BUBBLE_Y, defaultY)
        return x to y
    }

    fun addHistoryItem(context: Context, text: String, modelUsed: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return

        val current = loadHistory(context).toMutableList()
        val now = System.currentTimeMillis()
        current.add(
            0,
            TranscriptionRecord(
                id = now,
                text = trimmed,
                timestamp = now,
                modelUsed = modelUsed
            )
        )
        val capped = current.take(MAX_HISTORY_ITEMS)
        saveHistory(context, capped)
        _historyFlow.value = capped
    }

    fun clearHistory(context: Context) {
        getStandardPrefs(context).edit().remove(KEY_HISTORY_JSON).apply()
        _historyFlow.value = emptyList()
    }

    fun loadHistory(context: Context): List<TranscriptionRecord> {
        val raw = getStandardPrefs(context).getString(KEY_HISTORY_JSON, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = mutableListOf<TranscriptionRecord>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    TranscriptionRecord(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        text = obj.optString("text", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        modelUsed = obj.optString("modelUsed", DEFAULT_MODEL_NAME)
                    )
                )
            }
            result.filter { it.text.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveHistory(context: Context, list: List<TranscriptionRecord>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("timestamp", item.timestamp)
                put("modelUsed", item.modelUsed)
            }
            array.put(obj)
        }
        getStandardPrefs(context).edit().putString(KEY_HISTORY_JSON, array.toString()).apply()
    }
}
