package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.VoiceTypeProTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent {
            VoiceTypeProTheme {
                VoiceTypeMainScreen()
            }
        }
    }
}

data class PermissionChecklistState(
    val hasMicrophone: Boolean = false,
    val hasOverlay: Boolean = false,
    val hasAccessibility: Boolean = false,
    val hasNotifications: Boolean = false
) {
    val allGranted: Boolean
        get() = hasMicrophone && hasOverlay && hasAccessibility && hasNotifications
}

fun checkPermissionsState(context: Context): PermissionChecklistState {
    val micGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val overlayGranted = Settings.canDrawOverlays(context)
    val accessibilityGranted = VoiceTypeAccessibilityService.isServiceEnabled(context)

    val notificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    return PermissionChecklistState(
        hasMicrophone = micGranted,
        hasOverlay = overlayGranted,
        hasAccessibility = accessibilityGranted,
        hasNotifications = notificationsGranted
    )
}

@Composable
fun VoiceTypeMainScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var apiKeyInput by rememberSaveable { mutableStateOf(Prefs.getApiKey(context)) }
    var savedApiKey by rememberSaveable { mutableStateOf(Prefs.getApiKey(context)) }
    var showApiKey by rememberSaveable { mutableStateOf(false) }
    var modelNameInput by rememberSaveable { mutableStateOf(Prefs.getModelName(context)) }

    var isTestingApi by remember { mutableStateOf(false) }
    var testStatusMessage by remember { mutableStateOf<String?>(null) }
    var testStatusSuccess by remember { mutableStateOf(false) }

    var permissionState by remember { mutableStateOf(checkPermissionsState(context)) }
    val isServiceRunning by FloatingBubbleService.isRunningFlow.collectAsState()
    val historyList by Prefs.historyFlow.collectAsState()

    // Refresh permission status automatically in onResume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionState = checkPermissionsState(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        permissionState = checkPermissionsState(context)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        permissionState = checkPermissionsState(context)
    }

    val canStartFloatingMic = permissionState.allGranted && savedApiKey.isNotBlank()

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .testTag("main_lazy_column"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Hero Header Banner with Mic Icon & Bilingual Title
                item {
                    HeroHeaderCard(isServiceRunning = isServiceRunning)
                }

                // 2. Primary Start / Stop Floating Mic Button
                item {
                    FloatingMicActionCard(
                        isRunning = isServiceRunning,
                        canStart = canStartFloatingMic,
                        hasApiKey = savedApiKey.isNotBlank(),
                        allPermissionsGranted = permissionState.allGranted,
                        onToggleService = {
                            if (isServiceRunning) {
                                FloatingBubbleService.stop(context)
                            } else {
                                // Persist current model name before starting
                                Prefs.saveModelName(context, modelNameInput)
                                FloatingBubbleService.start(context)
                            }
                        }
                    )
                }

                // 3. Live Permission Checklist (Refreshed in onResume)
                item {
                    PermissionChecklistCard(
                        state = permissionState,
                        onRequestMic = {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onRequestOverlay = {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        },
                        onRequestAccessibility = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        },
                        onRequestNotification = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                    )
                }

                // 4. Gemini API Key & Model Configuration Card
                item {
                    ApiConfigurationCard(
                        apiKey = apiKeyInput,
                        onApiKeyChange = { apiKeyInput = it },
                        showApiKey = showApiKey,
                        onToggleShowApiKey = { showApiKey = !showApiKey },
                        modelName = modelNameInput,
                        onModelNameChange = {
                            modelNameInput = it
                            Prefs.saveModelName(context, it)
                        },
                        isTesting = isTestingApi,
                        statusMessage = testStatusMessage,
                        statusSuccess = testStatusSuccess,
                        onSaveAndTest = {
                            val trimmedKey = apiKeyInput.trim()
                            val trimmedModel = modelNameInput.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
                            modelNameInput = trimmedModel
                            Prefs.saveApiKey(context, trimmedKey)
                            Prefs.saveModelName(context, trimmedModel)
                            savedApiKey = trimmedKey

                            if (trimmedKey.isEmpty()) {
                                testStatusSuccess = false
                                testStatusMessage = "Please enter a Gemini API key first. (অনুগ্রহ করে এপিআই কী দিন)"
                                return@ApiConfigurationCard
                            }

                            isTestingApi = true
                            testStatusMessage = null
                            coroutineScope.launch {
                                val result = GeminiTranscriber.testApiKey(trimmedKey, trimmedModel)
                                isTestingApi = false
                                result.fold(
                                    onSuccess = { response ->
                                        testStatusSuccess = true
                                        if (response.usedFallbackModel) {
                                            testStatusMessage =
                                                "API Key saved & verified via fallback '${response.modelUsed}' (404 on '$trimmedModel' — consider updating model name)."
                                            Toast.makeText(
                                                context,
                                                "Model '$trimmedModel' returned 404. Verified with '${response.modelUsed}'.",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        } else {
                                            testStatusMessage =
                                                "API Key saved & verified with '${response.modelUsed}'! (এপিআই কী সফলভাবে যাচাই হয়েছে)"
                                        }
                                    },
                                    onFailure = { err ->
                                        testStatusSuccess = false
                                        testStatusMessage =
                                            "Saved key, but test failed: ${err.localizedMessage ?: "Error"}"
                                    }
                                )
                            }
                        }
                    )
                }

                // 5. Recent 20 Transcriptions History Section Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.history_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = stringResource(R.string.history_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (historyList.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    Prefs.clearHistory(context)
                                    Toast.makeText(context, "History cleared", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.testTag("clear_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = stringResource(R.string.clear_history),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = stringResource(R.string.clear_history))
                            }
                        }
                    }
                }

                if (historyList.isEmpty()) {
                    item {
                        EmptyHistoryCard()
                    }
                } else {
                    items(
                        items = historyList,
                        key = { it.id }
                    ) { record ->
                        HistoryItemCard(
                            record = record,
                            onCopy = {
                                TextInserter.copyToClipboard(context, record.text)
                                Toast.makeText(
                                    context,
                                    "Copied to clipboard (কপি করা হয়েছে)",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroHeaderCard(isServiceRunning: Boolean) {
    val gradientBrush = Brush.linearGradient(
        colors = listOf(
            Color(0xFF1E1B4B),
            Color(0xFF312E81),
            Color(0xFF0F172A)
        )
    )
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_header_card"),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(gradientBrush)
                .padding(20.dp)
        ) {
            // Decorative acoustic soundwave canvas in background
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
            ) {
                val barCount = 28
                val spacing = size.width / barCount
                for (i in 0 until barCount) {
                    val normalized = sin(i * 0.45f) * 0.5f + 0.5f
                    val barHeight = (12f + normalized * 46f).coerceAtMost(size.height)
                    val x = i * spacing + spacing / 2f
                    val startY = (size.height - barHeight) / 2f
                    drawLine(
                        color = Color(0x2238BDF8),
                        start = Offset(x, startY),
                        end = Offset(x, startY + barHeight),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(56.dp),
                    shape = CircleShape,
                    color = if (isServiceRunning) StatusGreen else Color(0xFF4F46E5)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = stringResource(R.string.app_name),
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isServiceRunning) Color(0x3310B981) else Color(0x3394A3B8)
                        ) {
                            Text(
                                text = if (isServiceRunning) "ACTIVE" else "READY",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isServiceRunning) Color(0xFF6EE7B7) else Color(0xFFCBD5E1),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.app_subtitle),
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFE0E7FF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tap bubble → [ 🎙️ MIC ] to toggle recording • [ ✕ ] to cancel or 30s undo",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}

@Composable
private fun FloatingMicActionCard(
    isRunning: Boolean,
    canStart: Boolean,
    hasApiKey: Boolean,
    allPermissionsGranted: Boolean,
    onToggleService: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("floating_mic_action_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onToggleService,
                enabled = isRunning || canStart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("toggle_floating_mic_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) StatusRed else MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (isRunning) {
                        stringResource(R.string.stop_floating_mic)
                    } else {
                        stringResource(R.string.start_floating_mic)
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!isRunning && !canStart) {
                val missingReason = when {
                    !allPermissionsGranted && !hasApiKey ->
                        "Grant all 4 permissions below and save your Gemini API key to enable the floating mic. (সব অনুমতি দিন এবং এপিআই কী সেভ করুন)"
                    !allPermissionsGranted ->
                        "Grant all required permissions below to enable the floating mic. (নিচের সব অনুমতি চালু করুন)"
                    else ->
                        "Save a Gemini API key below to enable the floating mic. (নিচে জেমিনি এপিআই কী সেভ করুন)"
                }
                Text(
                    text = missingReason,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PermissionChecklistCard(
    state: PermissionChecklistState,
    onRequestMic: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onRequestNotification: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("permission_checklist_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column {
                Text(
                    text = stringResource(R.string.permissions_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.permissions_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

            PermissionRowItem(
                icon = Icons.Default.Mic,
                title = stringResource(R.string.perm_mic_title),
                subtitle = stringResource(R.string.perm_mic_desc),
                isGranted = state.hasMicrophone,
                testTag = "perm_row_microphone",
                onClick = onRequestMic
            )

            PermissionRowItem(
                icon = Icons.Default.Layers,
                title = stringResource(R.string.perm_overlay_title),
                subtitle = stringResource(R.string.perm_overlay_desc),
                isGranted = state.hasOverlay,
                testTag = "perm_row_overlay",
                onClick = onRequestOverlay
            )

            PermissionRowItem(
                icon = Icons.Default.AccessibilityNew,
                title = stringResource(R.string.perm_accessibility_title),
                subtitle = stringResource(R.string.perm_accessibility_desc),
                isGranted = state.hasAccessibility,
                testTag = "perm_row_accessibility",
                onClick = onRequestAccessibility
            )

            PermissionRowItem(
                icon = Icons.Default.Notifications,
                title = stringResource(R.string.perm_notification_title),
                subtitle = stringResource(R.string.perm_notification_desc),
                isGranted = state.hasNotifications,
                testTag = "perm_row_notifications",
                onClick = onRequestNotification
            )
        }
    }
}

@Composable
private fun PermissionRowItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isGranted: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        if (isGranted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "✅",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Granted",
                    tint = StatusGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        } else {
            OutlinedButton(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "❌ Enable",
                    style = MaterialTheme.typography.labelLarge,
                    color = StatusRed
                )
            }
        }
    }
}

@Composable
private fun ApiConfigurationCard(
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    showApiKey: Boolean,
    onToggleShowApiKey: () -> Unit,
    modelName: String,
    onModelNameChange: (String) -> Unit,
    isTesting: Boolean,
    statusMessage: String?,
    statusSuccess: Boolean,
    onSaveAndTest: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("api_config_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column {
                Text(
                    text = stringResource(R.string.api_config_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.api_config_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            OutlinedTextField(
                value = apiKey,
                onValueChange = onApiKeyChange,
                label = { Text(stringResource(R.string.api_key_label)) },
                singleLine = true,
                visualTransformation = if (showApiKey) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = onToggleShowApiKey,
                        modifier = Modifier.testTag("toggle_api_key_visibility")
                    ) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showApiKey) "Hide API Key" else "Show API Key"
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_key_input")
            )

            OutlinedTextField(
                value = modelName,
                onValueChange = onModelNameChange,
                label = { Text(stringResource(R.string.model_name_label)) },
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null
                    )
                },
                supportingText = {
                    Text(
                        text = "Default: gemini-3.5-transcribe (auto-falls back to gemini-2.5-flash on 404)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("model_name_input")
            )

            Button(
                onClick = onSaveAndTest,
                enabled = !isTesting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_and_test_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isTesting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.testing_api))
                } else {
                    Text(stringResource(R.string.save_and_test))
                }
            }

            AnimatedVisibility(visible = statusMessage != null) {
                statusMessage?.let { msg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (statusSuccess) {
                                    StatusGreen.copy(alpha = 0.14f)
                                } else {
                                    StatusRed.copy(alpha = 0.14f)
                                }
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (statusSuccess) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = if (statusSuccess) StatusGreen else StatusRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHistoryCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_history_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Text(
                text = stringResource(R.string.history_empty),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HistoryItemCard(
    record: TranscriptionRecord,
    onCopy: () -> Unit
) {
    val formattedTime = remember(record.timestamp) {
        SimpleDateFormat("hh:mm:ss a • dd MMM", Locale.getDefault()).format(Date(record.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("history_item_${record.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = record.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFamily,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = record.modelUsed,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onCopy,
                modifier = Modifier.testTag("copy_history_${record.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy transcription",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
