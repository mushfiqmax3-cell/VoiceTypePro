package com.example

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TranscriptionResponse(
    val text: String,
    val modelUsed: String,
    val usedFallbackModel: Boolean
)

sealed class TranscriptionException(message: String) : Exception(message) {
    class NoInternet : TranscriptionException("No internet connection. Please check your network.")
    class InvalidApiKey : TranscriptionException("Invalid Gemini API key. Check your key in VoiceType Pro.")
    class QuotaExceeded : TranscriptionException("Quota exceeded (429). Please wait a moment and try again.")
    class EmptyResult : TranscriptionException("No speech detected (কোনো কথা শনাক্ত হয়নি).")
    class ApiError(msg: String) : TranscriptionException(msg)
}

/**
 * Handles inline base64 audio transcription with the Gemini API over OkHttp + Coroutines.
 * Uses official Google Generative Language REST API camelCase keys ("inlineData", "mimeType")
 * and defaults to "gemini-2.5-flash".
 */
object GeminiTranscriber {
    const val TRANSCRIPTION_PROMPT =
        "You are an expert bilingual speech-to-text engine for Bengali (বাংলা) and English. " +
        "Transcribe everything spoken in this audio with high fidelity. " +
        "Rules:\n" +
        "1. Write Bengali words in Bengali script (বাংলা হরফ) and English words in Latin alphabet (English).\n" +
        "2. Accurately transcribe mixed Bengali and English (Banglish) code-switching.\n" +
        "3. Even if the voice is soft, quiet, fast, or recorded through an emulator microphone, capture every audible spoken word verbatim.\n" +
        "4. Add natural sentence punctuation (যেমন: ।, ?, !, .).\n" +
        "5. Return ONLY the transcribed text. Do NOT add quotes, markdown formatting, explanations, apologies, or conversational filler."

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var activeCall: Call? = null

    /**
     * Cancels any in-flight OkHttp network request immediately.
     */
    fun cancelActiveRequest() {
        try {
            activeCall?.cancel()
        } catch (_: Exception) {
        } finally {
            activeCall = null
        }
    }

    /**
     * Reads the closed and flushed audio file safely into a byte array.
     */
    private fun readClosedAudioBytes(audioFile: File): ByteArray {
        FileInputStream(audioFile).use { fis ->
            return fis.readBytes()
        }
    }

    /**
     * Detects the MIME type from the audio file header or extension ("audio/wav" or "audio/mp4").
     */
    fun detectAudioMimeType(audioFile: File, bytes: ByteArray): String {
        if (bytes.size >= 12 &&
            bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte()
        ) {
            return "audio/wav"
        }
        return if (audioFile.extension.equals("wav", ignoreCase = true)) {
            "audio/wav"
        } else {
            "audio/mp4"
        }
    }

    /**
     * Sends the recorded audio file inline (Base64) to Gemini and returns the trimmed transcription.
     * Always deletes [audioFile] in the finally block (success, failure, or cancellation).
     */
    suspend fun transcribeAudio(
        audioFile: File,
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            if (!audioFile.exists() || audioFile.length() <= 44L) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val audioBytes = readClosedAudioBytes(audioFile)
            if (audioBytes.size <= 44) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val mimeType = detectAudioMimeType(audioFile, audioBytes)
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val requestBodyJson = buildTranscriptionJson(base64Audio, mimeType)

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = requestBodyJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = requestBodyJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                val text = cleanExtractedTranscript(fallbackAttempt.extractedText.orEmpty())
                if (text.isEmpty()) {
                    return@withContext Result.failure(TranscriptionException.EmptyResult())
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = text,
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            val text = cleanExtractedTranscript(primaryAttempt.extractedText.orEmpty())
            if (text.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            Result.success(
                TranscriptionResponse(
                    text = text,
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            cancelActiveRequest()
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            activeCall = null
            try {
                if (audioFile.exists()) {
                    audioFile.delete()
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Makes a tiny test request to validate the user's API key and model configuration.
     */
    suspend fun testApiKey(
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }

            val testJson = JSONObject().apply {
                val part = JSONObject().put("text", "Reply with OK")
                val parts = JSONArray().put(part)
                val content = JSONObject().put("parts", parts)
                put("contents", JSONArray().put(content))
                put("generationConfig", JSONObject().put("temperature", 0))
            }.toString()

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = testJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = testJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = fallbackAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            Result.success(
                TranscriptionResponse(
                    text = primaryAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Request timed out."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Validation failed."))
        }
    }

    /**
     * Builds the official Google Generative Language REST API JSON payload using camelCase keys:
     * parts: [ { "inlineData": { "mimeType": mimeType, "data": base64Audio } }, { "text": TRANSCRIPTION_PROMPT } ]
     */
    fun buildTranscriptionJson(base64Audio: String, mimeType: String = "audio/wav"): String {
        val inlineData = JSONObject().apply {
            put("mimeType", mimeType)
            put("data", base64Audio)
        }
        val audioPart = JSONObject().apply {
            put("inlineData", inlineData)
        }
        val textPart = JSONObject().apply {
            put("text", TRANSCRIPTION_PROMPT)
        }
        val partsArray = JSONArray().apply {
            put(audioPart)
            put(textPart)
        }
        val contentObj = JSONObject().apply {
            put("role", "user")
            put("parts", partsArray)
        }
        val contentsArray = JSONArray().apply {
            put(contentObj)
        }
        val generationConfig = JSONObject().apply {
            put("temperature", 0)
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", generationConfig)
        }.toString()
    }

    private fun cleanExtractedTranscript(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```") && text.endsWith("```")) {
            text = text.removeSurrounding("```").trim()
            if (text.startsWith("text\n") || text.startsWith("json\n")) {
                text = text.substringAfter('\n').trim()
            }
        }
        text = text.removeSurrounding("\"").removeSurrounding("'").trim()
        val lower = text.lowercase()
        if (lower == "no speech" ||
            lower == "no speech detected" ||
            lower == "no speech detected." ||
            lower == "[silence]" ||
            lower == "(silence)" ||
            lower == "silence" ||
            lower == "nothing" ||
            lower == "none"
        ) {
            return ""
        }
        return text
    }

    private data class RawApiAttempt(
        val extractedText: String? = null,
        val isModelNotFound: Boolean = false,
        val exception: TranscriptionException? = null
    )

    private suspend fun executeGenerateContent(
        model: String,
        apiKey: String,
        bodyJson: String
    ): RawApiAttempt {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val call = okHttpClient.newCall(request)
        activeCall = call

        val (code, responseBody) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
            cont.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (!cont.isCancelled) {
                        cont.resumeWithException(e)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { resp ->
                        val bodyStr = resp.body?.string().orEmpty()
                        if (!cont.isCancelled) {
                            cont.resume(resp.code to bodyStr)
                        }
                    }
                }
            })
        }

        if (code == 404) {
            return RawApiAttempt(isModelNotFound = true)
        }

        if (code == 400 || code == 401 || code == 403) {
            val lower = responseBody.lowercase()
            if (lower.contains("api_key_invalid") ||
                lower.contains("api key not valid") ||
                lower.contains("invalid api key") ||
                code == 401 || code == 403
            ) {
                return RawApiAttempt(exception = TranscriptionException.InvalidApiKey())
            }
            if (lower.contains("not found") || lower.contains("is not found for api version")) {
                return RawApiAttempt(isModelNotFound = true)
            }
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Request error ($code)."
                )
            )
        }

        if (code == 429) {
            return RawApiAttempt(exception = TranscriptionException.QuotaExceeded())
        }

        if (code !in 200..299) {
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Server error ($code)."
                )
            )
        }

        val extracted = extractCandidatesText(responseBody)
        return RawApiAttempt(extractedText = extracted)
    }

    fun extractCandidatesText(jsonString: String): String {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.optJSONObject(0) ?: return ""
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val builder = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue
                val text = part.optString("text", "")
                if (text.isNotEmpty()) {
                    builder.append(text)
                }
            }
            builder.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseErrorMessage(jsonString: String): String? {
        return try {
            val root = JSONObject(jsonString)
            val err = root.optJSONObject("error") ?: return null
            err.optString("message", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
