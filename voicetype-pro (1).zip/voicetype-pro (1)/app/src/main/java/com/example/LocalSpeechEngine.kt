package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import java.util.Locale

/**
 * Dedicated On-Device Offline Speech Engine utilizing Android's native [SpeechRecognizer]
 * and [RecognizerIntent] with [RecognizerIntent.EXTRA_PREFER_OFFLINE] = true.
 *
 * Supports Bengali ("bn-BD"), English ("en-US"), and Device Default locales, and provides
 * system settings intents to download/manage offline language models.
 */
class LocalSpeechEngine(private val context: Context) {

    companion object {
        const val LANG_BENGALI_BD = "bn-BD"
        const val LANG_ENGLISH_US = "en-US"

        /**
         * Returns true if SpeechRecognizer is supported on this Android device.
         */
        fun isRecognitionAvailable(context: Context): Boolean {
            return try {
                SpeechRecognizer.isRecognitionAvailable(context)
            } catch (_: Exception) {
                false
            }
        }

        /**
         * Launches the system Offline Speech Recognition language management screen
         * (`ACTION_MANAGE_SPEECH_RECOGNITION_LANGUAGES` or Google Voice Typing settings
         * `Settings.ACTION_VOICE_INPUT_SETTINGS`) so the user can download offline
         * Bengali (বাংলা) and English language packs directly.
         */
        fun openOfflineLanguageDownloadSettings(context: Context) {
            val manageLanguagesAction = "android.speech.action.MANAGE_SPEECH_RECOGNITION_LANGUAGES"
            val candidates = listOf(
                Intent(manageLanguagesAction).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                },
                Intent("com.google.android.googlequicksearchbox.MANAGE_OFFLINE_SPEECH_LANGUAGES").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                },
                Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                },
                Intent(Settings.ACTION_LOCALE_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                },
                Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )

            for (intent in candidates) {
                try {
                    context.startActivity(intent)
                    return
                } catch (_: Exception) {
                    // Try next fallback intent
                }
            }

            Toast.makeText(
                context,
                "Open System Settings → System → Languages & Input → On-device recognition to download Bengali & English packs.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private val partialTranscriptBuffer = StringBuilder()

    @Volatile
    private var isListeningActive = false

    @Volatile
    private var hasDeliveredCallback = false

    /**
     * Starts on-device speech recognition on the main thread.
     *
     * @param preferOffline When true, sets [RecognizerIntent.EXTRA_PREFER_OFFLINE] = true.
     * @param languageOverride Optional BCP-47 language tag ("bn-BD", "en-US", or "" for default).
     * @param onResult Invoked with the recognized text when recognition completes.
     * @param onError Invoked with a clear user-facing error message if recognition fails.
     */
    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        preferOffline: Boolean = true,
        languageOverride: String? = null
    ) {
        mainHandler.post {
            try {
                destroyInternal()
                partialTranscriptBuffer.clear()
                hasDeliveredCallback = false

                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    hasDeliveredCallback = true
                    onError("On-device Speech Recognition is not available on this device.")
                    return@post
                }

                val recognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
                speechRecognizer = recognizer

                val selectedTag = languageOverride ?: Prefs.getOfflineLanguage(context).localeTag
                val effectiveTag = selectedTag.ifBlank { Locale.getDefault().toLanguageTag() }

                val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, effectiveTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, effectiveTag)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }

                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListeningActive = true
                    }

                    override fun onBeginningOfSpeech() {
                        isListeningActive = true
                    }

                    override fun onRmsChanged(rmsdB: Float) = Unit

                    override fun onBufferReceived(buffer: ByteArray?) = Unit

                    override fun onEndOfSpeech() {
                        isListeningActive = false
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val bestPartial = matches?.firstOrNull { it.isNotBlank() }?.trim()
                        if (!bestPartial.isNullOrEmpty()) {
                            partialTranscriptBuffer.clear()
                            partialTranscriptBuffer.append(bestPartial)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListeningActive = false
                        if (hasDeliveredCallback) return
                        hasDeliveredCallback = true

                        val matches = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val bestText = matches
                            ?.firstOrNull { it.isNotBlank() }
                            ?.trim()
                            ?.ifEmpty { partialTranscriptBuffer.toString().trim() }
                            ?: partialTranscriptBuffer.toString().trim()

                        destroyInternal()
                        if (bestText.isNotEmpty()) {
                            onResult(bestText)
                        } else {
                            onError("No speech detected (কোনো কথা শনাক্ত হয়নি).")
                        }
                    }

                    override fun onError(error: Int) {
                        isListeningActive = false
                        if (hasDeliveredCallback) return

                        // If partial results were already captured before silence/timeout, deliver them
                        val fallbackPartial = partialTranscriptBuffer.toString().trim()
                        destroyInternal()

                        if (fallbackPartial.isNotEmpty()) {
                            hasDeliveredCallback = true
                            onResult(fallbackPartial)
                            return
                        }

                        // If offline language pack is not yet installed on device, retry seamlessly without forcing offline
                        if (preferOffline &&
                            (error == SpeechRecognizer.ERROR_NETWORK ||
                                error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                error == SpeechRecognizer.ERROR_SERVER ||
                                error == 12 ||
                                error == 13)
                        ) {
                            startListening(
                                onResult = onResult,
                                onError = onError,
                                preferOffline = false,
                                languageOverride = languageOverride
                            )
                            return
                        }

                        hasDeliveredCallback = true
                        onError(mapSpeechError(error))
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })

                isListeningActive = true
                recognizer.startListening(recognizerIntent)
            } catch (e: Exception) {
                isListeningActive = false
                if (!hasDeliveredCallback) {
                    hasDeliveredCallback = true
                    onError(e.localizedMessage ?: "Failed to start offline speech recognizer.")
                }
            }
        }
    }

    /**
     * Signals the recognizer that the user has stopped speaking so final results are emitted.
     */
    fun stopListening() {
        mainHandler.post {
            try {
                if (isListeningActive) {
                    speechRecognizer?.stopListening()
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Immediately cancels recognition and discards any pending callback.
     */
    fun cancel() {
        mainHandler.post {
            hasDeliveredCallback = true
            isListeningActive = false
            partialTranscriptBuffer.clear()
            destroyInternal()
        }
    }

    private fun destroyInternal() {
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
    }

    private fun mapSpeechError(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO ->
                "Microphone audio error during offline recognition."
            SpeechRecognizer.ERROR_CLIENT ->
                "Offline speech client error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Microphone permission is required."
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Offline language pack not installed yet. Tap 'Download Offline Languages' in VoiceType Pro."
            SpeechRecognizer.ERROR_NO_MATCH ->
                "No speech recognized. Please speak clearly."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "Speech recognizer is busy. Please try again."
            SpeechRecognizer.ERROR_SERVER ->
                "Speech recognition service unavailable. Download offline language packs in Settings."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "No speech detected."
            12 /* SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED */,
            13 /* SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE */ ->
                "Selected offline language pack is not downloaded yet. Please download it in Settings."
            else ->
                "Speech recognition error (code $errorCode)."
        }
    }
}
