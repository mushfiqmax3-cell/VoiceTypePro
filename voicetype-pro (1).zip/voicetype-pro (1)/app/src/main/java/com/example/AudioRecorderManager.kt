package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * High-reliability Audio Recorder that captures raw 16kHz 16-bit mono PCM audio via [AudioRecord],
 * applies smart automatic gain normalization (so quiet microphones are boosted to clear speech levels),
 * and writes a standard RIFF `.wav` ("audio/wav") file to [Context.getCacheDir].
 *
 * Why WAV + AudioRecord instead of MediaRecorder MPEG_4:
 * 1. Zero container corruption — RIFF WAV headers are written deterministically from exact byte counts.
 * 2. Real-time amplitude monitoring & digital gain normalization — prevents Gemini from receiving
 *    near-silent audio streams that previously caused "No speech detected".
 * 3. Instant start/stop with no AAC encoder warm-up cutoff.
 */
class AudioRecorderManager(
    private val context: Context,
    private val onMaxDurationReached: () -> Unit
) {
    companion object {
        const val SAMPLE_RATE_HZ = 16_000
        const val MAX_DURATION_MS = 120_000
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM
        private const val MAX_PCM_BYTES =
            (SAMPLE_RATE_HZ * BYTES_PER_SAMPLE * (MAX_DURATION_MS / 1000))
    }

    @Volatile
    private var isRecording = false

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private var currentOutputFile: File? = null
    private var pcmBufferStream: ByteArrayOutputStream? = null

    @Volatile
    var lastPeakAmplitude: Int = 0
        private set

    @Synchronized
    fun startRecording(): Result<File> {
        stopAndReleaseInternal()
        val outputFile = File(
            context.cacheDir,
            "voicetype_rec_${System.currentTimeMillis()}.wav"
        )
        currentOutputFile = outputFile
        lastPeakAmplitude = 0

        return try {
            val minBufSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE_HZ,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufSize * 2, SAMPLE_RATE_HZ)

            val record = createAudioRecord(bufferSize)
                ?: throw IllegalStateException("Microphone is unavailable or in use by another app.")

            val byteStream = ByteArrayOutputStream(SAMPLE_RATE_HZ * 10)
            pcmBufferStream = byteStream
            audioRecord = record

            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                record.release()
                audioRecord = null
                throw IllegalStateException("Microphone failed to enter recording state.")
            }

            isRecording = true
            val thread = Thread({
                readAudioLoop(record, byteStream)
            }, "VoiceTypeAudioRecordThread")
            recordingThread = thread
            thread.start()

            Result.success(outputFile)
        } catch (e: Exception) {
            stopAndReleaseInternal()
            deleteFileSafely(outputFile)
            currentOutputFile = null
            Result.failure(e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun createAudioRecord(bufferSize: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.DEFAULT
        )
        for (source in sources) {
            try {
                val ar = AudioRecord(
                    source,
                    SAMPLE_RATE_HZ,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                if (ar.state == AudioRecord.STATE_INITIALIZED) {
                    return ar
                }
                ar.release()
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun readAudioLoop(record: AudioRecord, output: ByteArrayOutputStream) {
        val shortBuffer = ShortArray(1024)
        val byteChunk = ByteArray(shortBuffer.size * 2)

        while (isRecording) {
            val readCount = try {
                record.read(shortBuffer, 0, shortBuffer.size)
            } catch (_: Exception) {
                -1
            }

            if (readCount > 0) {
                var chunkPeak = 0
                for (i in 0 until readCount) {
                    val sample = shortBuffer[i].toInt()
                    val absVal = if (sample == Short.MIN_VALUE.toInt()) 32767 else abs(sample)
                    if (absVal > chunkPeak) {
                        chunkPeak = absVal
                    }
                    // Little-endian 16-bit PCM
                    byteChunk[i * 2] = (sample and 0xFF).toByte()
                    byteChunk[i * 2 + 1] = ((sample shr 8) and 0xFF).toByte()
                }
                if (chunkPeak > lastPeakAmplitude) {
                    lastPeakAmplitude = chunkPeak
                }

                synchronized(output) {
                    output.write(byteChunk, 0, readCount * 2)
                    if (output.size() >= MAX_PCM_BYTES) {
                        isRecording = false
                        onMaxDurationReached()
                    }
                }
            } else if (readCount < 0) {
                break
            }
        }
    }

    /**
     * Stops recording, normalizes low-volume microphone audio so speech is crystal clear,
     * writes the complete RIFF WAV file to disk, and returns the `.wav` file.
     */
    @Synchronized
    fun stopRecording(): File? {
        val file = currentOutputFile
        val stream = pcmBufferStream
        if (!isRecording && (stream == null || stream.size() == 0)) {
            stopAndReleaseInternal()
            return null
        }

        isRecording = false
        try {
            recordingThread?.join(800L)
        } catch (_: Exception) {
        }
        recordingThread = null

        stopAndReleaseAudioRecordOnly()

        return try {
            val rawPcm = if (stream != null) {
                synchronized(stream) { stream.toByteArray() }
            } else {
                ByteArray(0)
            }
            pcmBufferStream = null

            // Require at least 0.15s of audio bytes
            if (file == null || rawPcm.size < SAMPLE_RATE_HZ / 4) {
                deleteFileSafely(file)
                return null
            }

            val normalizedPcm = normalizePcm16Le(rawPcm)
            writeWavFile(file, normalizedPcm, SAMPLE_RATE_HZ)

            if (file.exists() && file.length() > 44L) {
                file
            } else {
                deleteFileSafely(file)
                null
            }
        } catch (e: Exception) {
            deleteFileSafely(file)
            null
        }
    }

    /**
     * Stops recording immediately and deletes any temporary audio file (used when ✕ is tapped).
     */
    @Synchronized
    fun cancelAndDeleteRecording() {
        val file = currentOutputFile
        isRecording = false
        try {
            recordingThread?.join(400L)
        } catch (_: Exception) {
        }
        recordingThread = null
        stopAndReleaseInternal()
        deleteFileSafely(file)
        currentOutputFile = null
    }

    private fun stopAndReleaseInternal() {
        isRecording = false
        stopAndReleaseAudioRecordOnly()
        pcmBufferStream = null
    }

    private fun stopAndReleaseAudioRecordOnly() {
        val record = audioRecord
        audioRecord = null
        if (record != null) {
            try {
                if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    record.stop()
                }
            } catch (_: Exception) {
            }
            try {
                record.release()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Normalizes 16-bit little-endian PCM audio if the microphone gain is low,
     * ensuring Gemini receives a strong, clear speech signal without clipping.
     */
    fun normalizePcm16Le(pcmBytes: ByteArray): ByteArray {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return pcmBytes

        var peak = 0
        var sumSquares = 0.0
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = (high shl 8) or low
            val absSample = if (sample == Short.MIN_VALUE.toInt()) 32767 else abs(sample)
            if (absSample > peak) peak = absSample
            sumSquares += sample.toDouble() * sample.toDouble()
        }

        // If peak is already strong (>= 18000) or completely zero, return as-is
        if (peak == 0 || peak >= 18_000) {
            return pcmBytes
        }

        val rms = sqrt(sumSquares / sampleCount)
        // Compute a safe gain multiplier (up to 10x) so quiet mics reach ~24,000 peak
        val targetPeak = 24_000.0
        val gain = (targetPeak / peak.toDouble()).coerceIn(1.0, if (rms > 25.0) 10.0 else 4.0)

        val out = ByteArray(pcmBytes.size)
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = (high shl 8) or low
            val boosted = (sample * gain).toInt().coerceIn(-32767, 32767)
            out[i * 2] = (boosted and 0xFF).toByte()
            out[i * 2 + 1] = ((boosted shr 8) and 0xFF).toByte()
        }
        return out
    }

    /**
     * Writes a standard 44-byte RIFF WAVE header followed by 16-bit mono PCM data.
     */
    fun writeWavFile(outputFile: File, pcmData: ByteArray, sampleRate: Int) {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * BYTES_PER_SAMPLE

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // Subchunk1Size for PCM
            putShort(1) // AudioFormat = 1 (PCM)
            putShort(1) // NumChannels = 1 (Mono)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(BYTES_PER_SAMPLE.toShort()) // BlockAlign
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        FileOutputStream(outputFile).use { fos ->
            fos.write(header)
            fos.write(pcmData)
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Exception) {
            }
        }
    }

    fun deleteFileSafely(file: File?) {
        try {
            if (file != null && file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }
}
